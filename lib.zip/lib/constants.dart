import 'package:flutter/material.dart';

const kPrimaryColor = Color.fromARGB(255, 70, 7, 79);
const kPrimaryLightColor = Color.fromARGB(255, 244, 242, 242);

const double defaultPadding = 16.0;
